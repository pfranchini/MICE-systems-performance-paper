#!/bin/bash

echo ".L $(dirname $0)/process.C+" | root -l -b
